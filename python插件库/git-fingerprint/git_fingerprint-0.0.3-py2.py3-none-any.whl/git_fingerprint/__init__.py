#!/usr/bin/env python3
__version__ = "0.0.3"
__author__ = "Luke Paris (Paradoxis) <luke@paradoxis.nl>"

from git_fingerprint.scanner import Scanner
from git_fingerprint.exceptions import GitFingerprintException
