#!/usr/bin/env python3


class GitFingerprintException(Exception):
    pass
