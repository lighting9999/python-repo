VERSION = '1.0.0'
LIBRARY_NAME = 'screenshot-api-python'
