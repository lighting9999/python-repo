from pip_run import run


__name__ == '__main__' and run()
