# Copyright 2017, Aaron Hosford

import sys

from . import main


sys.exit(main())
