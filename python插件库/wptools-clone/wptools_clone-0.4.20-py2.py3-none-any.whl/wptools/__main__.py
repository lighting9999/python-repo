from wptools.wptool import main, parse_args


if __name__ == "__main__":
    main(parse_args())
