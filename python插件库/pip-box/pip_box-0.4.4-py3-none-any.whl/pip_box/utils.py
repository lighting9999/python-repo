"""
    TODO - get packages deps from pypi before download
"""


class QueryDependencies:
    def __init__(self):
        pass

    