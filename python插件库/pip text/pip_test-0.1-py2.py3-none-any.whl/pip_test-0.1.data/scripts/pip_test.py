#!python

print "Hello World"
