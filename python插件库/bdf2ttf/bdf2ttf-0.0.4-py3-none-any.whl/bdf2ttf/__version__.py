# Single source of truth for the package version. See
# https://packaging.python.org/guides/single-sourcing-package-version/
__version__ = "0.0.4"
