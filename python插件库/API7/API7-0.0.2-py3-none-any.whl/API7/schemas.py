import enum

class SortOrder(enum.Enum):
    '''Sort order of collections'''
    ASC = "ASC"
    DESC = "DESC"
