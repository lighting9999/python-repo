"""Main entry point."""
# pylint: disable=invalid-name
import pip_update

pip_update.run_main()
