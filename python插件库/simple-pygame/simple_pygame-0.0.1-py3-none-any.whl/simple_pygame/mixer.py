"""A module for playing sounds."""
try:
    from .sound import Sound
except ImportError:
    pass