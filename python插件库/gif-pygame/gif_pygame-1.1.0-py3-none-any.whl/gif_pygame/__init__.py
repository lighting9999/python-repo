from gif_pygame.gif_pygame import load, PygameGIF, GIFPygame, version
import gif_pygame.transform as transform