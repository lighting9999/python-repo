"""Flatpak packaging for pygame games.
"""

__version__ = '0.1'
